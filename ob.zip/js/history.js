//culture.js

$(document).ready(function(){

	
	$(".container").animate({opacity:"1"},2000,"linear");
	$(window).scroll(function(){
		var top=$(document).scrollTop();
		
		if (top>0)
			{
				$("#masthead").css({background:"rgba(2,65,134,0.5)"});
			}else if (top==0)
			{
				$("#masthead").css({background: "rgba(0,0,0,0)"});
			}//if
	});
});//doc