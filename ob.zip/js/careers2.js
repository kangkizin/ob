//careers2.js


$(document).ready(function(){
		//$('.bgimg-1 .caption .border').css({display:"none"})
	
	$(window).scroll(function(){
			var topvar=$(document).scrollTop(); 
			var top=$(document).scrollTop(); 
			var one1=$(".oneone1").offset().top; 
			var one2=$(".oneone2").offset().top; 
			var one3=$(".oneone3").offset().top; 
			var one4=$(".bgbgbg .caption").offset().top; 
			var dd=$(document).height();
			//console.log(one1);

			if (topvar>=750)
			{
				$(".topkey").css({"display":"block"});
			}else{
				$(".topkey").css({"display":"none"});
			}//if

			if (top>=one1-530)
			{
					//$(".oneone1").animate({"opacity":"1"});
					$(".oneone1 h3").css({"display":"block"});
					$(".oneone1 p").css({"display":"block"});
			}

			if (top>=one2-560)
			{
				
					$(".oneone2 h3").css({"display":"block"});
					$(".oneone2 p").css({"display":"block"});
			}

			if (top>=one3-550)
			{
		
					$(".oneone3 ul li img").css({"display":"block"});
					
			}

			if (top>=one4-550)
			{
		
					$(".bgbgbg .caption .border").css({"display":"block"});
					$(".bgbgbg .caption .spec").css({"display":"block"});
					
			}


			if (top>0)
			{
				$("#masthead").css({background:"rgba(2,65,134,0.5)"});
			}else if (top==0)
			{
				$("#masthead").css({background: "rgba(0,0,0,0)"});
			}//if

		});//window scrollTop
 

});//doc