//index.js

$(document).ready(function(){
	//$(".section .comhi").css({opacity:0});
	doctopp=$(window).height();
	topp=$(document).scrollTop();
	cc=$(".section .comhi").offset().top;
	cc2=$(".section .comhi2").offset().top;
	cc3=$(".section .comhi3").offset().top;
	//console.log(topp, doctopp);
	
	$(window).on("load scroll resize",function(){
		topp=$(document).scrollTop();
		cc=$(".section .comhi").offset().top;
		cc2=$(".section .comhi2").offset().top;
		cc3=$(".section .comhi4").offset().top;
		//console.log(topp, doctopp, cc);
		if (topp>=cc-400)
		{
			//$(".section .comhi .cobox").animate({opacity:"1"});
			//$(".section .comhi .cobox").css({display:"block"});
			$(".section .comhi").stop().animate({opacity:"1"},500,"linear",function(){
				$(".section .comhi .cobox").css({"display":"block"});
			});
		}

		if (topp>=cc2-400)
		{
			//$(".section .comhi .cobox").animate({opacity:"1"});
			//$(".section .comhi .cobox").css({display:"block"});
			$(".section .comhi2").stop().animate({opacity:"1"},500,"linear",function(){
				$(".section .comhi2 .cobox").css({"display":"block"});
			});
			$(".section .comhi3").stop().animate({opacity:"1"},500,"linear",function(){
				$(".section .comhi3 .cobox").css({"display":"block"});
			});
			$(".section .ob1").css({"display":"block"});
		}

		if (topp>=cc3-400)
		{
			//$(".section .comhi .cobox").animate({opacity:"1"});
			//$(".section .comhi .cobox").css({display:"block"});
			$(".section .comhi4").stop().animate({opacity:"1"},500,"linear",function(){
				$(".section .comhi4 .cobox").css({"display":"block"});
			});
		}

		var top=$(document).scrollTop();
		
		if (top>0)
			{
				$("#masthead").css({background:"rgba(2,65,134,0.5)"});
			}else if (top==0)
			{
				$("#masthead").css({background: "rgba(0,0,0,0)"});
			}//if
	});


});//doc