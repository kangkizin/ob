//loading.js

$(document).ready(function(){});//doc