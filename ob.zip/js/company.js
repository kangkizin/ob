//company.js

$(document).ready(function(){
	$(".section .cott2").css({"display":"none"});

	$(window).on("load scroll resize",function(){
		topp=$(document).scrollTop();
		c1=$(".com1").offset().top;
		c2=$(".com2").offset().top;
		c3=$(".com3").offset().top;
		c4=$(".com4").offset().top;
		console.log(c3,c4);
		if (topp>=c1-350)
		{
			$(".com1").stop().animate({opacity:"1"},500,"linear",function(){
				$(".com1 img").css({"display":"block"});
				$(".com1 .com1right").css({"display":"block"});
			});
		}

		if (topp>=c2-420)
		{
			$(".com2").stop().animate({opacity:"1"},500,"linear",function(){
				$(".com2 img").css({"display":"block"});
				$(".com2 .com2right").css({"display":"block"});
			});
		}

		if (topp>=c3-430)
		{
			$(".com3").stop().animate({opacity:"1"},500,"linear",function(){
				$(".com3 img").css({"display":"block"});
				$(".com3 .com3right").css({"display":"block"});
			});
		}

	

		if (topp>=c4-330)
		{
			$(".com4").stop().animate({opacity:"1"},500,"linear",function(){
				$(".section .com4 .cott2").css({"display":"block"});
				$(".com4 img").css({"display":"block"});
				$(".com4 .com4right").css({"display":"block"});
			});
		}

		var top=$(document).scrollTop();
		
		if (top>0)
			{
				$("#masthead").css({background:"rgba(2,65,134,0.5)"});
			}else if (top==0)
			{
				$("#masthead").css({background: "rgba(0,0,0,0)"});
			}//if
			
				

	});
});//doc