//templete.js


$(document).ready(function(){
	$(window).scroll(function(){
			var topvar=$(document).scrollTop(); 
			var dd=$(document).height();
			//console.log(topvar, dd);

			if (topvar>=750)
			{
				$(".topkey").css({"display":"block"});
				$(".top2").css({"display":"block"});
			}else{
				$(".topkey").css({"display":"none"});
				$(".top2").css({"display":"none"});
			}//if

			if (topvar>0)
			{
				$("#masthead").css({background:"rgba(2,65,134,0.5)"});
			}else if (topvar==0)
			{
				$("#masthead").css({background:"rgba(0,0,0,0)"});
			}//if

		});//window scrollTop

		$(".topkey").click(function(){
			$("html, body").animate({
				scrollTop:0
			}, 1000,);
		});
		var sui=$(document).height();
		$(".top2").click(function(){
			$("html, body").animate({
				scrollTop:sui
			}, 1000,);
		});

		$(".social>li:nth-child(1)>a").click(function(){ 
			window.open("https://www.facebook.com/OrientalBreweryCompany/");
		});

		$(".social>li:nth-child(2)>a").click(function(){ 
			window.open("https://www.linkedin.com/company/abinbevkoreaobc");
		});

		$(".social>li:nth-child(3)>a").click(function(){
			window.open("https://www.instagram.com/official.obc/");
		});

		$(".ul1>li:nth-child(4)").click(function(){
			window.open("https://www.facebook.com/OrientalBreweryCompany/");
		});

		$(".ul1>li:nth-child(5)").click(function(){
			window.open("https://www.ob.co.kr/post/228");
		});

		$(".ul1>li:nth-child(6)").click(function(){
			window.open("https://blog.naver.com/abipeople");
		});

		
});//doc