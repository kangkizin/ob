//world.js

$(document).ready(function(){
		$("#sect1 .bgbg").delay(2000).animate({opacity:"0.4"},1000);
		$(".nav").delay(2000).animate({opacity:"1"},1000);

		
			$(".nav>ul>li>a").click(function(e){
				$(".nav>ul>li>a").removeClass("on");
				$(this).addClass("on")

				var href=$(this).attr("href");
				var scrt=$(href).offset().top;
				//console.log(href, scrt);
				$("html, body").stop().animate({scrollTop:scrt},900, "swing");
				e.preventDefault();
			});//nav a click


			$('section').mousewheel(function(event, delta){
				if (delta>0)
				{
					//alert("UP");
					var prev_pos=$(this).prev().position().top;
					$("html, body").stop().animate({"scrollTop":prev_pos},1200,"linear");
				}else if (delta<0)
				{
					//alert("DOWN")
					var next_pos=$(this).next().position().top;
					$("html, body").stop().animate({"scrollTop":next_pos},1200,"linear");
				}//if
			});//section mousewheel




			$(window).scroll(function(){
				www=-400;
				h=$(window).height();//브라우저에서 스크롤이동 전의 화면 높이를 구함	
				scrt=$(window).scrollTop();//브라우저에서 스크롤바의 꼭대기 위치값을 구함
				//console.log("브라우저 높이"+h, "현재스크롤바의 꼭대기 위치"+scrt);

				for (var i=0; i<5 ;i++ )
				{
					if (scrt>=h*i+www && scrt<h*(i+1)+www)
						////(scrt>=i*h && scrt<(i+1)*h
					{
						$(".nav>ul>li>a").removeClass("on");
						$(".nav>ul>li>a").eq(i).addClass("on");
					}//if
				}//for

				var top=$(document).scrollTop();
		
				if (top>0)
				{
					$("#masthead").css({background:"rgba(2,65,134,0.0)"});
					//$("#masthead").css({background:"rgba(0,0,0,0.0)"});
				}else if (top==0)
					{
						$("#masthead").css({background: "rgba(0,0,0,0)"});
					}//if
			});//window scroll
		});//doc