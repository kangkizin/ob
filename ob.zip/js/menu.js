//menu.js
$(document).ready(function(){
$(function() {
    $('body').addClass('js');
  
    var $hamburger = $('.hamburger'),
        $nav = $('#site-nav'),
        $masthead = $('#masthead');
  
    $hamburger.click(function() {
      $(this).toggleClass('is-active');
      $nav.toggleClass('is-active');
      $masthead.toggleClass('is-active');
	  $("#maintitle").toggleClass('is-active');
      return false; 
    })

	 $("#maintitle").click(function(){
		$(location).attr('href',"index.html"); 
	 });
});
});//doc