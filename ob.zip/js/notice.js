//notice.js

$(document).ready(function(){
	$('.btns_more').click(function(){
		var toto=$('.cha').offset().top;
		$('html, body').animate({scrollTop:toto-150},1500);
	});
});